package com.hummingbee.tests;

import com.hummingbee.system.Garden;

public class SystemDateTester {
	public static void main(String[] args) {
		Garden.getInstance();
	}
}
